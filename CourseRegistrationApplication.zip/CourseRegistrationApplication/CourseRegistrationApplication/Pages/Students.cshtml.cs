using Microsoft.AspNetCore.Mvc.RazorPages;


public class StudentsModel : PageModel
{
    public List<Student> Students { get; set; } = new List<Student>();

    public void OnGet()
    {
        Students = new List<Student>
        {
            new Student { StudentId = 1, FirstName = "Sam", LastName = "Pit", Email = "sam.pit@gmail.com", PhoneNumber = "647-012-1234" },
            new Student { StudentId = 2, FirstName = "May", LastName = "Timber", Email = "may.timber@gmail.com", PhoneNumber = "647-012-3456" }
        };
    }

    public class Student
    {
        public int StudentId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
    }
}
