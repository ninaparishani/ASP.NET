using Microsoft.AspNetCore.Mvc.RazorPages;


public class InstructorsModel : PageModel
{
    public List<Instructor> Instructors { get; set; } = new List<Instructor>();

    public void OnGet()
    {
        Instructors = new List<Instructor>
        {
                new Instructor { InstructorId = 1, FirstName = "Tom", LastName = "Smith", Email = "tom.smith@gmail.com",Course = new Course { CourseId = 1, CourseNumber = "DNDS201", CourseName = "ASP Web Applications", Description = "Basics of ASP.NET." } },
                new Instructor { InstructorId = 2, FirstName = "Mary", LastName = "Brown", Email = "mary.brown@gmail.com", Course = new Course { CourseId = 2, CourseNumber = "MND301", CourseName = "MSSQL Database", Description = "Creating and maintaining legacy databases." } }
            };
    }

    public class Course
    {
        public int CourseId { get; set; }
        public string CourseNumber { get; set; } = string.Empty;
        public string CourseName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }

    public class Instructor
    {
        public int InstructorId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public Course Course { get; set; } = new Course();
    }
}
