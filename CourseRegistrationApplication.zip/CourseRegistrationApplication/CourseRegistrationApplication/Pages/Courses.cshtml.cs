using Microsoft.AspNetCore.Mvc.RazorPages;


public class CoursesModel : PageModel
{
    public List<Course> Courses { get; set; } = new List<Course>();

    public void OnGet()
    {
        Courses = new List<Course>
        {
            new Course { CourseId = 1, CourseNumber = "DNDS201", CourseName = "ASP Web Applications", Description = "Basics of ASP.NET." },
            new Course { CourseId = 2, CourseNumber = "MND301", CourseName = "MSSQL Database", Description = "Creating and maintaining legacy databases." }
        };
    }

    public class Course
    {
        public int CourseId { get; set; }
        public string CourseNumber { get; set; } = string.Empty;
        public string CourseName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }
}
