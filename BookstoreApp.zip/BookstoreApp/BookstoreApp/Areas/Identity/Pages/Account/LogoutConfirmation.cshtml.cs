﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookstoreApp.Areas.Identity.Pages.Account
{
    public class LogoutConfirmationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
